module.exports = {
    client: 'sqlite3',
    connection: {
        filename: './database/database.sqlite'
    }
};


