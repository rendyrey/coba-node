# nodejs-sqlite3
Experiment on NODE server + SQLITE3 database
